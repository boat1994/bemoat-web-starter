#!/usr/bin/env node
import { mkdtempSync, rmSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { tmpdir } from 'node:os'
import { spawnSync } from 'node:child_process'
import { Buffer } from 'buffer'

const PRE_DELIVERY_STATES = new Set(['READY', 'IN_PROGRESS'])
const CORE_VERDICTS = new Set([
  'CORRECTION REQUIRED',
  'ELIGIBLE FOR FOUNDER REVIEW',
  'BLOCKED FOR FOUNDER DECISION',
  'BLOCKED EXTERNAL',
  'STATE CONFLICT',
])

const VERDICT_TO_STATE = {
  'CORRECTION REQUIRED': {
    1: 'CORRECTION_REQUIRED_1',
    2: 'CORRECTION_REQUIRED_2',
  },
  'ELIGIBLE FOR FOUNDER REVIEW': 'ELIGIBLE_FOR_FOUNDER_REVIEW',
  'BLOCKED FOR FOUNDER DECISION': 'BLOCKED_FOR_FOUNDER_DECISION',
  'BLOCKED EXTERNAL': 'BLOCKED_EXTERNAL',
  'STATE CONFLICT': 'STATE_CONFLICT',
}

const REPAIR_OUTCOMES = new Set([
  'DETERMINISTIC_MIGRATION',
  'BOOKKEEPING_REPAIR',
  'TERMINAL_REPAIR',
])

function sameValue(left, right) {
  return JSON.stringify(left) === JSON.stringify(right)
}

function hasLegacyManagedState(state = {}) {
  return (
    Object.hasOwn(state, 'post_budget_review_history') ||
    Object.hasOwn(state, 'founder_authorization') ||
    Object.hasOwn(state, 'founder_correction_authorization')
  )
}

/**
 * Exhaustive, ordered reconciliation classification. Only contradictory live
 * authority is a conflict; schema and bookkeeping lag remain repairable.
 */
export function classifyReconciliation(evidence = {}) {
  if (evidence.classification) return evidence.classification
  if (evidence.requiredEvidenceUnavailable) {
    return { outcome: 'BLOCKED_EXTERNAL', reason: 'required live evidence is unavailable' }
  }
  if (
    evidence.authoritativeContradiction ||
    evidence.competingPrs ||
    evidence.headMismatch ||
    evidence.staleCi
  ) {
    return { outcome: 'STATE_CONFLICT', reason: 'authoritative live evidence contradicts' }
  }

  const terminal = evidence.terminal ?? {}
  if (terminal.prMerged && (
    !terminal.issueClosed ||
    !terminal.reviewedHeadMatches ||
    !terminal.currentHeadMatches ||
    typeof terminal.mergeCommit !== 'string' || terminal.mergeCommit.length === 0 ||
    terminal.exactHeadCi !== true
  )) {
    return { outcome: 'STATE_CONFLICT', reason: 'terminal evidence is incomplete or does not bind the reviewed head' }
  }
  if (terminal.issueClosed && terminal.prMerged && terminal.reviewedHeadMatches && terminal.currentHeadMatches && terminal.mergeCommit && terminal.exactHeadCi) {
    if (evidence.managedState?.state === 'DONE') {
      return { outcome: 'NO_OP', reason: 'terminal evidence already recorded' }
    }
    return { outcome: 'TERMINAL_REPAIR', reason: 'terminal bookkeeping lags live merge evidence' }
  }

  if (hasLegacyManagedState(evidence.managedState)) {
    return { outcome: 'DETERMINISTIC_MIGRATION', reason: 'legacy managed-state representation is unambiguous' }
  }
  if (evidence.bookkeepingProposal) {
    const proposed = { ...(evidence.managedState ?? {}), ...evidence.bookkeepingProposal }
    if (sameValue(proposed, evidence.managedState ?? {})) {
      return { outcome: 'NO_OP', reason: 'bookkeeping evidence is already recorded' }
    }
    return { outcome: 'BOOKKEEPING_REPAIR', reason: 'unambiguous live evidence is ahead of bookkeeping' }
  }
  return { outcome: 'NO_OP', reason: 'no authoritative evidence changed' }
}

/**
 * Convert the Issue #155 legacy post-budget fields to their canonical shape.
 * Superseded keys are removed only from the proposed replacement state; the
 * caller owns the single durable write and verification.
 */
export function migrateLegacyManagedState(managedState = {}) {
  if (!hasLegacyManagedState(managedState)) {
    return { changed: false, state: managedState }
  }

  const state = structuredClone(managedState)
  if (Object.hasOwn(state, 'post_budget_review_history') && !Array.isArray(state.post_budget_review_history)) {
    throw new Error('legacy post_budget_review_history must be an array')
  }
  const history = state.post_budget_review_history ?? []
  const legacyReviewAuthorization = state.founder_authorization

  if (Object.hasOwn(state, 'post_budget_reviews') && !Array.isArray(state.post_budget_reviews)) {
    throw new Error('canonical post_budget_reviews must be an array')
  }
  const normalizeReview = (entry) => {
    if (typeof entry !== 'object' || entry === null || Array.isArray(entry)) {
      throw new Error('post-budget review entries must be mappings')
    }
    return {
      ...structuredClone(entry),
      authorization:
        entry.authorization ??
        (legacyReviewAuthorization?.review_number === entry.review_number &&
        legacyReviewAuthorization?.reviewed_head === entry.reviewed_head
          ? structuredClone(legacyReviewAuthorization)
          : null),
    }
  }
  const reviewsByNumber = new Map()
  for (const entry of [...(state.post_budget_reviews ?? []), ...history]) {
    const normalized = normalizeReview(entry)
    const existing = reviewsByNumber.get(normalized.review_number)
    if (existing && !sameValue(existing, normalized)) {
      throw new Error(`contradictory post-budget review ${normalized.review_number}`)
    }
    reviewsByNumber.set(normalized.review_number, normalized)
  }
  if (reviewsByNumber.size > 0) {
    state.post_budget_reviews = [...reviewsByNumber.values()].sort((left, right) => left.review_number - right.review_number)
  }

  if (!state.founder_decision && state.founder_correction_authorization) {
    state.founder_decision = structuredClone(state.founder_correction_authorization)
  }

  if (state.state === 'STATE_CONFLICT') {
    const latestReview = state.post_budget_reviews?.at(-1) ?? null
    const decision = state.founder_decision
    const validCorrection =
      latestReview &&
      decision?.status === 'approved' &&
      decision?.authority === 'Founder' &&
      decision?.scope === 'correction' &&
      decision?.for_review_number === latestReview.review_number &&
      decision?.reviewed_head === latestReview.reviewed_head &&
      Array.isArray(decision?.finding_ids) && decision.finding_ids.length > 0 &&
      decision.finding_ids.every((id) => latestReview.finding_dispositions?.some((finding) => finding.finding_id === id))
    if (decision && !validCorrection) {
      throw new Error('invalid Founder correction authorization cannot grant IN_PROGRESS')
    }
    state.state = validCorrection ? 'IN_PROGRESS' : 'BLOCKED_FOR_FOUNDER_DECISION'
  }

  for (const review of state.post_budget_reviews ?? []) {
    if (review.authorization?.status !== 'approved' || review.authorization?.authority !== 'Founder' ||
      review.authorization?.scope !== 'review' || review.authorization?.review_number !== review.review_number ||
      review.authorization?.reviewed_head !== review.reviewed_head) {
      throw new Error(`invalid Founder review authorization for Review ${review.review_number}`)
    }
  }

  // The complete canonical representation is proven before any legacy key is removed.
  delete state.post_budget_review_history
  delete state.founder_authorization
  delete state.founder_correction_authorization

  return { changed: true, state }
}

function proposedRepair(evidence, classification) {
  if (evidence.proposedState) return structuredClone(evidence.proposedState)
  const migrated = migrateLegacyManagedState(evidence.managedState ?? {}).state
  if (classification.outcome === 'TERMINAL_REPAIR') {
    return {
      ...migrated,
      state: 'DONE',
      merged_commit_sha: evidence.terminal?.mergeCommit ?? migrated.merged_commit_sha ?? null,
      open_blockers: [],
      next_permitted_action: 'none on this task',
    }
  }
  if (classification.outcome === 'BOOKKEEPING_REPAIR') {
    return { ...migrated, ...evidence.bookkeepingProposal }
  }
  return migrated
}

/**
 * Run at most one deterministic repair and one live verification. A second
 * repair is never attempted in the same run.
 */
export async function runBoundedReconciliation({ readEvidence, writeState }) {
  const measurements = {
    coordination_runs: 1,
    state_writes: 0,
    role_comments: 0,
    model_required_stages: 0,
    reconciliation_attempts: 0,
    false_state_conflicts: 0,
  }

  const initialEvidence = await readEvidence()
  measurements.reconciliation_attempts += 1
  const initial = classifyReconciliation(initialEvidence)
  if (!REPAIR_OUTCOMES.has(initial.outcome)) {
    return { ...initial, finalOutcome: initial.outcome, measurements }
  }

  let proposed
  try {
    proposed = proposedRepair(initialEvidence, initial)
  } catch (error) {
    return {
      ...initial,
      finalOutcome: 'STATE_CONFLICT',
      finalReason: error instanceof Error ? error.message : String(error),
      measurements,
    }
  }
  const written = await writeState(proposed, initialEvidence.managedState)
  if (!sameValue(written, proposed)) {
    throw new Error('durable reconciliation write was not confirmed')
  }
  measurements.state_writes += 1

  const verifiedEvidence = await readEvidence()
  measurements.reconciliation_attempts += 1
  const verified = classifyReconciliation(verifiedEvidence)
  const verificationStillRequestsRepair = REPAIR_OUTCOMES.has(verified.outcome)
  return {
    ...initial,
    finalOutcome: verificationStillRequestsRepair ? 'STATE_CONFLICT' : verified.outcome,
    finalReason: verificationStillRequestsRepair
      ? 'bounded repair was not confirmed by the single verification'
      : verified.reason,
    measurements,
  }
}

/**
 * Transactional READY -> IN_PROGRESS dispatch with compensating rollback.
 * The caller supplies durable Issue and role-comment operations so this logic
 * remains testable and transport-agnostic.
 */
export async function dispatchManagedTask({ readState, writeState, postHandoff, retractHandoff, handoffBody, transitionState }) {
  const original = await readState()
  if (original?.state !== 'READY') {
    throw new Error(`dispatch requires READY, received ${original?.state ?? 'missing state'}`)
  }
  if (!/^## HANDOFF\s*$/m.test(handoffBody ?? '')) {
    throw new Error('dispatch requires one HANDOFF role comment')
  }

  const defaultTransition = (state) => ({ ...structuredClone(state), state: 'IN_PROGRESS' })
  const dispatched = (transitionState ?? defaultTransition)(original)
  await writeState(dispatched)
  if (!sameValue(await readState(), dispatched)) {
    throw new Error('dispatch verification found a concurrent state change before HANDOFF')
  }
  let handoff = null
  try {
    handoff = await postHandoff(handoffBody)
  } catch (error) {
    const live = await readState()
    if (!sameValue(live, dispatched)) {
      throw new Error('dispatch failed and concurrent state change prevented rollback', { cause: error })
    }
    await writeState(original)
    throw new Error('dispatch rolled back after HANDOFF failure', { cause: error })
  }

  const verified = await readState()
  if (!sameValue(verified, dispatched)) {
    if (!retractHandoff || !handoff) {
      throw new Error('dispatch verification found a concurrent state change and cannot retract HANDOFF')
    }
    await retractHandoff(handoff)
    throw new Error('dispatch verification found a concurrent state change')
  }
  return { outcome: 'DISPATCHED', state: verified }
}

/**
 * @param {string} body
 */
export function parseRoleCommentBody(body = '') {
  const heading = body.match(/^##\s+(HANDOFF|RESULT|REVIEW_VERDICT)\s*$/m)?.[1] ?? null
  if (!heading) {
    return { role: null, body, prNumber: null, headSha: null, verdict: null, managedStateLine: null }
  }

  const prFromUrl = body.match(/https:\/\/github\.com\/[\w.-]+\/[\w.-]+\/pull\/(\d+)/)?.[1] ?? null
  const prFromHash = body.match(/\bPR\s*#(\d+)\b/i)?.[1] ?? null
  const headFromState = body.match(/\*\*State:\*\*[^\n]*head\s+`([0-9a-f]{7,40})`/i)?.[1] ?? null
  const headFromPrLine = body.match(/\*\*PR\s*\/\s*base\s*\/\s*head:\*\*[^\n]*·\s*`([0-9a-f]{7,40})`/i)?.[1] ?? null
  const headFromExact = body.match(/\*\*Exact head reviewed:\*\*\s*`([0-9a-f]{7,40})`/i)?.[1] ?? null
  const headSha =
    headFromState ||
    headFromPrLine ||
    headFromExact ||
    (body.match(/head\s+`([0-9a-f]{7,40})`/i)?.[1] ?? null)
  const verdict = body.match(/^\*\*Verdict:\*\*\s*(.+?)\s*$/m)?.[1]?.trim() ?? null
  const managedStateLine = body.match(/^\*\*Managed state:\*\*\s*(.+?)\s*$/m)?.[1]?.trim() ?? null

  return {
    role: heading,
    body,
    prNumber: prFromUrl || prFromHash,
    headSha,
    verdict,
    managedStateLine,
  }
}

/**
 * @param {Array<{ body?: string, createdAt?: string }>} comments
 * @param {'RESULT' | 'REVIEW_VERDICT'} role
 */
export function findLatestRoleComment(comments = [], role) {
  const matches = comments
    .map((comment) => ({ comment, parsed: parseRoleCommentBody(comment.body ?? '') }))
    .filter((entry) => entry.parsed.role === role)

  if (matches.length === 0) return null

  matches.sort((left, right) => {
    const leftTime = Date.parse(left.comment.createdAt ?? '') || 0
    const rightTime = Date.parse(right.comment.createdAt ?? '') || 0
    return rightTime - leftTime
  })

  return matches[0]
}

export function classifyDeliveryLag(managedState, livePr, exactHeadCi, latestResult = null) {
  if (!managedState?.state || !PRE_DELIVERY_STATES.has(managedState.state)) {
    return { lag: false, kind: null, reason: 'state is not pre-delivery' }
  }

  const stalePointers =
    managedState.active_pr == null ||
    managedState.current_head == null ||
    managedState.state !== 'AWAITING_REVIEW_1'

  if (!stalePointers) {
    return { lag: false, kind: null, reason: 'delivery state already recorded' }
  }

  if (!livePr?.number || !livePr.headRefOid) {
    return { lag: true, kind: 'INCOMPLETE_DELIVERY', reason: 'missing live PR evidence' }
  }

  const resultPr = latestResult?.parsed?.prNumber ?? null
  if (latestResult && !resultPr) {
    return { lag: false, kind: 'STATE_CONFLICT', reason: 'RESULT PR identifier missing' }
  }
  if (resultPr && String(resultPr) !== String(livePr.number)) {
    return { lag: false, kind: 'STATE_CONFLICT', reason: 'RESULT PR does not match live PR' }
  }

  const resultHead = latestResult?.parsed?.headSha ?? null
  const headsAlign =
    !resultHead || resultHead === livePr.headRefOid || resultHead.startsWith(livePr.headRefOid.slice(0, 7))

  if (!headsAlign) {
    return { lag: false, kind: 'STATE_CONFLICT', reason: 'RESULT head does not match live PR head' }
  }

  if (exactHeadCi && exactHeadCi.exactHeadVerified === false) {
    return { lag: true, kind: 'INCOMPLETE_DELIVERY', reason: 'exact-head CI not verified' }
  }

  if (!latestResult) {
    return { lag: true, kind: 'INCOMPLETE_DELIVERY', reason: 'delivery RESULT not found' }
  }

  return { lag: true, kind: 'DETERMINISTIC_RECONCILIATION', reason: 'unambiguous delivery evidence' }
}

export function classifyReviewLag(managedState, livePr, latestVerdict = null) {
  if (!managedState?.state || !latestVerdict?.parsed?.verdict) {
    return { lag: false, kind: null, reason: 'no review verdict evidence' }
  }

  const awaitingStates = /^AWAITING_REVIEW_\d+$/
  const correctionStates = /^CORRECTION_REQUIRED_\d+$/
  const verdict = latestVerdict.parsed.verdict
  const reviewedHead = latestVerdict.parsed.headSha

  if (!CORE_VERDICTS.has(verdict)) {
    return { lag: false, kind: 'STATE_CONFLICT', reason: 'invalid review verdict enum' }
  }

  const verdictPr = latestVerdict.parsed.prNumber ?? null
  if (livePr?.number && !verdictPr) {
    return { lag: false, kind: 'STATE_CONFLICT', reason: 'REVIEW_VERDICT PR identifier missing' }
  }
  if (verdictPr && livePr?.number && String(verdictPr) !== String(livePr.number)) {
    return { lag: false, kind: 'STATE_CONFLICT', reason: 'REVIEW_VERDICT PR does not match live PR' }
  }

  if (reviewedHead && livePr?.headRefOid && reviewedHead !== livePr.headRefOid) {
    return { lag: false, kind: 'STATE_CONFLICT', reason: 'verdict head does not match live PR head' }
  }

  const expectedState = resolveVerdictState(verdict, managedState.review_cycle ?? 0)
  if (managedState.state === expectedState && managedState.last_reviewed_head === reviewedHead) {
    return { lag: false, kind: null, reason: 'review state already recorded' }
  }

  if (awaitingStates.test(managedState.state) || correctionStates.test(managedState.state)) {
    return { lag: true, kind: 'DETERMINISTIC_RECONCILIATION', reason: 'post-review bookkeeping lag' }
  }

  return { lag: false, kind: null, reason: 'state does not indicate review lag' }
}

export function classifyMergeDrift(authorizedHead, liveHead) {
  if (!authorizedHead || !liveHead) {
    return { drift: true, reason: 'missing authorized or live head for merge transition' }
  }
  if (authorizedHead !== liveHead) {
    return { drift: true, reason: 'authorized merge head does not match live PR head' }
  }
  return { drift: false, reason: null }
}

export function isGenuineStateConflict(evidence = {}) {
  if (evidence.competingPrs) return true
  if (evidence.headMismatch) return true
  if (evidence.staleCi) return true
  if ((evidence.stateConflictBlockers ?? []).some((blocker) => blocker.includes('STATE_CONFLICT'))) {
    return true
  }
  return false
}

export function proposeDeliveryReconciliation(evidence) {
  const prNumber = String(evidence.livePr.number)
  const head = evidence.latestResult?.parsed?.headSha || evidence.livePr.headRefOid
  const approvedBase = evidence.approvedBase || evidence.livePr.baseRefName || 'main'

  return {
    state: 'AWAITING_REVIEW_1',
    review_cycle: 0,
    full_review_count: 0,
    approved_base: approvedBase,
    active_task_issue: evidence.activeTaskIssue ? `"#${evidence.activeTaskIssue}"` : null,
    active_pr: `"#${prNumber}"`,
    current_head: head,
    last_reviewed_head: null,
    next_permitted_action: `Reviewer performs bounded Review 1 on PR #${prNumber} at exact head ${head}.`,
    material_change_status: 'none',
  }
}

export function resolveVerdictState(verdict, currentReviewCycle = 0) {
  if (verdict === 'CORRECTION REQUIRED') {
    const nextCycle = Math.min(currentReviewCycle + 1, 3)
    return VERDICT_TO_STATE['CORRECTION REQUIRED'][nextCycle] ?? 'STATE_CONFLICT'
  }
  return VERDICT_TO_STATE[verdict] ?? 'STATE_CONFLICT'
}

export function proposeReviewReconciliation(input) {
  const reviewCycle = input.reviewCycle ?? 0

  if (input.verdict === 'CORRECTION REQUIRED' && reviewCycle >= 2) {
    return {
      state: 'STATE_CONFLICT',
      review_cycle: reviewCycle,
      full_review_count: Math.min(input.fullReviewCount ?? 0, 1),
      last_reviewed_head: input.reviewedHead,
      next_permitted_action: 'Mission Control must classify contradictory evidence.',
    }
  }

  const nextCycle = Math.min(reviewCycle + 1, 3)

  let currentFull = input.fullReviewCount ?? 0
  const nextFullReviewCount = Math.min(currentFull + (reviewCycle === 0 ? 1 : 0), 1)

  return {
    state: resolveVerdictState(input.verdict, reviewCycle),
    review_cycle: nextCycle,
    full_review_count: nextFullReviewCount,
    last_reviewed_head: input.reviewedHead,
    next_permitted_action: nextActionForVerdict(input.verdict, nextCycle),
  }
}

function nextActionForVerdict(verdict, reviewCycle) {
  if (verdict === 'CORRECTION REQUIRED') {
    return `Dev posts correction ## RESULT, then Review ${Math.min(reviewCycle + 1, 3)} on the corrected head.`
  }
  if (verdict === 'ELIGIBLE FOR FOUNDER REVIEW') {
    return 'Founder merge authorization required before merge.'
  }
  if (verdict === 'BLOCKED FOR FOUNDER DECISION') {
    return 'Founder Approve or Decline on remaining Blocker/Critical; no implementation prompt until Approve.'
  }
  if (verdict === 'BLOCKED EXTERNAL') {
    return 'Resolve external blocker before continuing.'
  }
  return 'Mission Control must classify contradictory evidence.'
}

export function founderMergeTransitionAuthorized({ mergeAuthorized = false, migrationAuthorized = false, deployAuthorized = false } = {}) {
  return {
    mergeAllowed: mergeAuthorized,
    migrationAllowed: migrationAuthorized,
    deployAllowed: deployAuthorized,
    boundedSequence: mergeAuthorized && !migrationAuthorized && !deployAuthorized,
  }
}

export function analyzeReconciliation(context) {
  const terminalEvidence = context.terminal ?? null
  const genuineConflict = isGenuineStateConflict({
    stateConflictBlockers: context.stateConflictBlockers,
    headMismatch: Boolean(
      !terminalEvidence?.prMerged &&
      context.managedState?.current_head &&
        context.livePr?.headRefOid &&
        context.managedState.current_head !== context.livePr.headRefOid,
    ),
    staleCi: context.exactHeadCi?.exactHeadVerified === false && context.exactHeadCi?.olderShaSuccess === true,
  })

  const deliveryLag = classifyDeliveryLag(
    context.managedState,
    context.livePr,
    context.exactHeadCi,
    context.latestResult,
  )
  const reviewLag = classifyReviewLag(context.managedState, context.livePr, context.latestVerdict)

  let bookkeepingProposal = null
  let bookkeepingType = null
  if (deliveryLag.kind === 'DETERMINISTIC_RECONCILIATION' && context.livePr) {
    bookkeepingType = 'delivery'
    bookkeepingProposal = proposeDeliveryReconciliation({
      livePr: context.livePr,
      activeTaskIssue: context.activeTaskIssue,
      approvedBase: context.managedState?.approved_base,
      latestResult: context.latestResult,
    })
  } else if (reviewLag.kind === 'DETERMINISTIC_RECONCILIATION' && context.latestVerdict?.parsed?.verdict) {
    bookkeepingType = 'review'
    bookkeepingProposal = proposeReviewReconciliation({
      verdict: context.latestVerdict.parsed.verdict,
      reviewedHead: context.latestVerdict.parsed.headSha || context.livePr?.headRefOid,
      reviewCycle: context.managedState?.review_cycle ?? 0,
      fullReviewCount: context.managedState?.full_review_count ?? 0,
    })
  }

  const classification = classifyReconciliation({
    authoritativeContradiction: genuineConflict,
    requiredEvidenceUnavailable: context.requiredEvidenceUnavailable,
    managedState: context.managedState,
    terminal: terminalEvidence,
    bookkeepingProposal,
  })

  const result = {
    genuineConflict,
    classification,
    delivery: deliveryLag,
    review: reviewLag,
    proposal: null,
  }

  if (classification.outcome === 'STATE_CONFLICT' || classification.outcome === 'BLOCKED_EXTERNAL') {
    return result
  }

  if (classification.outcome === 'TERMINAL_REPAIR') {
    result.proposal = {
      type: 'terminal',
      fields: proposedRepair(context, classification),
    }
  } else if (classification.outcome === 'DETERMINISTIC_MIGRATION') {
    try {
      result.proposal = {
        type: 'migration',
        fields: migrateLegacyManagedState(context.managedState).state,
      }
    } catch (error) {
      result.classification = {
        outcome: 'STATE_CONFLICT',
        reason: error instanceof Error ? error.message : String(error),
      }
      result.proposal = null
    }
  } else if (classification.outcome === 'BOOKKEEPING_REPAIR' && bookkeepingType) {
    result.proposal = {
      type: bookkeepingType,
      fields: bookkeepingProposal,
    }
  }

  return result
}

function run(command, args) {
  const result = spawnSync(command, args, { encoding: 'utf8' })
  if (result.error || result.status !== 0) {
    throw new Error(result.stderr || result.stdout || result.error?.message || `${command} failed`)
  }
  return result.stdout.trim()
}

function parseReconcileArgs(argv) {
  const options = { issue: null, repo: null }
  for (let index = 0; index < argv.length; index += 1) {
    const argument = argv[index]
    if (argument === '--') continue
    if (argument === '--repo') {
      const repo = argv[++index]
      if (!repo) throw new Error('--repo requires a value')
      options.repo = repo
      continue
    }
    if (argument.startsWith('-') || options.issue) throw new Error(`unexpected argument: ${argument}`)
    options.issue = argument
  }
  if (!options.issue || !/^[1-9]\d*$/.test(options.issue)) {
    throw new Error('Usage: pnpm run bemoat:mission-control:reconcile -- <issue-number> [--repo owner/repo]')
  }
  return options
}

function stateBlockReplacement(body, state, renderMissionControlState) {
  const rendered = renderMissionControlState(state)
  const pattern = /<!--\s*bemoat-mission-control-state:start\s*-->[\s\S]*?<!--\s*bemoat-mission-control-state:end\s*-->/
  if (!pattern.test(body)) throw new Error('managed state block is missing')
  return body.replace(pattern, rendered)
}

async function runProductionBoundedReconciliation() {
  const options = parseReconcileArgs(process.argv.slice(2))
  const repoArgs = options.repo ? ['--repo', options.repo] : []
  const { analyzeProgressTracking } = await import('./agent-issue.mjs')
  const { parseMissionControlState, renderMissionControlState } = await import('./mission-control-state.mjs')
  let expectedBody = null

  const readEvidence = async () => {
    const issue = JSON.parse(run('gh', ['issue', 'view', options.issue, '--json', 'body,state', ...repoArgs]))
    const state = parseMissionControlState(issue.body)
    if (!state.present || !state.valid) throw new Error(`invalid managed state: ${state.reason ?? 'missing state block'}`)
    expectedBody = issue.body
    const analysis = analyzeProgressTracking({
      activeIssueBody: issue.body,
      activeIssueNumber: options.issue,
      activeIssueState: issue.state,
    })
    const reconciliation = analysis.report.reconciliation
    if (!reconciliation) throw new Error('production preflight did not produce reconciliation evidence')
    return {
      managedState: state.state,
      classification: reconciliation.classification,
      proposedState: reconciliation.proposal?.fields ?? null,
    }
  }

  const writeState = async (nextState, expectedState) => {
    const live = JSON.parse(run('gh', ['issue', 'view', options.issue, '--json', 'body', ...repoArgs]))
    const liveState = parseMissionControlState(live.body)
    if (!liveState.valid || !sameValue(liveState.state, expectedState) || live.body !== expectedBody) {
      throw new Error('concurrent Issue write detected before reconciliation repair')
    }
    const nextBody = stateBlockReplacement(live.body, nextState, renderMissionControlState)
    const temp = mkdtempSync(join(tmpdir(), 'bemoat-reconcile-'))
    const bodyFile = join(temp, 'issue.md')
    try {
      writeFileSync(bodyFile, nextBody)
      run('gh', ['issue', 'edit', options.issue, '--body-file', bodyFile, ...repoArgs])
      const verified = JSON.parse(run('gh', ['issue', 'view', options.issue, '--json', 'body', ...repoArgs]))
      const verifiedState = parseMissionControlState(verified.body)
      if (!verifiedState.valid || !sameValue(verifiedState.state, nextState)) {
        throw new Error('concurrent Issue write detected after reconciliation repair')
      }
      expectedBody = verified.body
      return verifiedState.state
    } finally {
      rmSync(temp, { recursive: true, force: true })
    }
  }

  const result = await runBoundedReconciliation({ readEvidence, writeState })
  if (result.finalOutcome === 'STATE_CONFLICT') {
    throw new Error(result.finalReason)
  }
  process.stdout.write(`Mission Control reconciliation ${result.finalOutcome}: ${result.measurements.reconciliation_attempts} attempt(s), ${result.measurements.state_writes} durable write(s)\n`)
}

// Comment projection helpers (inlined from former scripts/github-comment-projection.mjs)
// Kept inside this managed module so child harness sync does not require a non-managed path.
function getCommentBody(comment) {
  return comment.body || comment.body_html || ''
}

function isExplicitlyNonAuthoritativeRoleBody(body) {
  return (
    /\[(?:diagnostic|stale|superseded)\]/i.test(body) ||
    (/\b(?:hereby\s+)?superseded\b/i.test(body) && /\bnot\s+authorized\b/i.test(body)) ||
    /\bnot\s+authoritative\b/i.test(body)
  )
}

function isDiagnosticOrReconciliationRoleBody(body) {
  return (
    /\b(?:mission\s+control|state(?:-conflict)?)\s+reconciliation\b/i.test(body) ||
    /\bPhase:\s*(?:Mission Control|State)\s*(?:Reconciliation|Reconciler)/i.test(body) ||
    /\bno\s+repository\s+code\b/i.test(body) ||
    /\blocal-only\s+evidence\b/i.test(body)
  )
}

function hasApprovedOrDeliveryRoleBody(body, role) {
  if (/founder_decision:\s*approved/i.test(body)) return true
  if (/authorization:\s*[\s\S]*?status:\s*approved/i.test(body)) return true
  if (role === 'REVIEW_VERDICT' && /^\*\*Verdict:\*\*/m.test(body)) return true
  if (role === 'RESULT' && (
    /\bPR:\s*#\d+/i.test(body) ||
    /\*\*PR:\*\*/i.test(body) ||
    /\*\*Delivery\*\*/i.test(body) ||
    /Branch\s*\/\s*Head:/i.test(body) ||
    /Exact head(?: reviewed)?:/i.test(body) ||
    /Commands reported/i.test(body) ||
    /\bPhase:\s*Dev\b/i.test(body)
  )) return true
  if (role === 'HANDOFF' && /\*\*Target:\*\*/i.test(body) && /\*\*Objective:\*\*/i.test(body)) return true
  return false
}

/**
 * Select authoritative role comments using approval/delivery and supersession
 * semantics instead of timestamp-only comparison.
 *
 * @param {Array<Record<string, unknown>>} comments
 * @param {'HANDOFF' | 'RESULT' | 'REVIEW_VERDICT'} role
 */
export function selectAuthoritativeRoleComments(comments = [], role) {
  const authoritative = new Set()

  const roleEntries = comments
    .map((comment) => ({ comment, body: getCommentBody(comment) }))
    .filter(({ body }) => parseRoleCommentBody(body).role === role)

  const viable = roleEntries.filter(({ body }) => !isExplicitlyNonAuthoritativeRoleBody(body))
  const approved = viable.filter(({ body }) => hasApprovedOrDeliveryRoleBody(body, role))
  const diagnostic = viable.filter(({ body }) => isDiagnosticOrReconciliationRoleBody(body))

  if (approved.length > 0) {
    const latestApproved = findLatestRoleComment(
      approved.map(({ comment }) => comment),
      role,
    )
    if (latestApproved) authoritative.add(latestApproved.comment)
  } else if (diagnostic.length > 0) {
    const latestDiagnostic = findLatestRoleComment(
      diagnostic.map(({ comment }) => comment),
      role,
    )
    if (latestDiagnostic) authoritative.add(latestDiagnostic.comment)
  } else if (viable.length > 0) {
    const latest = findLatestRoleComment(
      viable.map(({ comment }) => comment),
      role,
    )
    if (latest) authoritative.add(latest.comment)
  }

  for (const { comment, body } of roleEntries) {
    const parsed = parseRoleCommentBody(body)
    if (!parsed.role) continue
    const ts = Date.parse(comment.createdAt || comment.created_at || '')
    if (Number.isNaN(ts)) {
      authoritative.add(comment)
    }
  }

  return authoritative
}

export function projectComments(comments = []) {
  if (!Array.isArray(comments)) return comments

  const authoritativeComments = new Set()

  const roles = ['HANDOFF', 'RESULT', 'REVIEW_VERDICT']
  for (const role of roles) {
    for (const comment of selectAuthoritativeRoleComments(comments, role)) {
      authoritativeComments.add(comment)
    }
  }

  return comments.map(rawComment => {
    let body = rawComment.body
    if (!body && rawComment.body_html) {
      body = rawComment.body_html
    } else if (!body) {
      body = ''
    }

    const isAuthoritative = authoritativeComments.has(rawComment)
    const isFounderDecision =
      body.includes('founder_decision:') ||
      body.includes('Founder decision:') ||
      /\b[Ff]ounder\s+gate:\s*Required\b/.test(body) ||
      body.includes('ELIGIBLE FOR FOUNDER REVIEW')

    let projectedBody = body
    if (!isAuthoritative && !isFounderDecision) {
      const parsed = parseRoleCommentBody(body)
      if (parsed && parsed.role) {
        projectedBody = `[Superseded ${parsed.role} comment. View original at ${rawComment.url || 'GitHub'}]`
      } else if (body.length > 500) {
        projectedBody = body.substring(0, 500) + `...\n\n[Comment truncated for context size. View full comment at ${rawComment.url || 'GitHub'}]`
      }
    }

    const projected = {
      id: rawComment.id || rawComment.node_id,
      url: rawComment.url,
      author: rawComment.author?.login || rawComment.user?.login || 'unknown',
      body: projectedBody
    }

    const createdAt = rawComment.createdAt || rawComment.created_at
    if (createdAt !== undefined) projected.createdAt = createdAt

    if (rawComment.path !== undefined) projected.path = rawComment.path
    if (rawComment.line !== undefined) projected.line = rawComment.line
    if (rawComment.inReplyTo || rawComment.in_reply_to_id) {
      projected.inReplyTo = rawComment.inReplyTo || rawComment.in_reply_to_id
    }
    const updatedAt = rawComment.updatedAt || rawComment.updated_at
    if (updatedAt !== undefined) projected.updatedAt = updatedAt

    const prReviewId = rawComment.pullRequestReviewId || rawComment.pull_request_review_id
    if (prReviewId !== undefined) projected.pullRequestReviewId = prReviewId

    if (rawComment.side !== undefined) projected.side = rawComment.side
    const startLine = rawComment.startLine || rawComment.start_line
    if (startLine !== undefined) projected.startLine = startLine

    const startSide = rawComment.startSide || rawComment.start_side
    if (startSide !== undefined) projected.startSide = startSide

    return projected
  })
}

export function benchmarkProjection(rawComments, projectedComments) {
  const rawJson = JSON.stringify(rawComments) || '[]'
  const projJson = JSON.stringify(projectedComments) || '[]'

  return {
    rawBytes: Buffer.byteLength(rawJson, 'utf8'),
    rawTokens: Math.ceil(rawJson.length / 4),
    projectedBytes: Buffer.byteLength(projJson, 'utf8'),
    projectedTokens: Math.ceil(projJson.length / 4)
  }
}


if (process.argv[1]?.endsWith('/mission-control-reconcile.mjs')) {
  runProductionBoundedReconciliation().catch((error) => {
    process.stderr.write(`ERROR: ${error instanceof Error ? error.message : String(error)}\n`)
    process.exitCode = 1
  })
}
